const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("MyNFT", function () {
   let MyNFT;
   let myNFT;
   let owner;
   let addr1;

  this.beforeEach(async function(){
     MyNFT = await ethers.getContractFactory("MyNFT");
     [owner] = await ethers.getSigners();

     myNFT = await MyNFT.deploy("ipfs://QmZbWNKJPAjxXuNFSEaksCJVd1M6DaKQViJBYPK2BdpDEP/");
     await myNFT.deployed(owner.address);
  })

  it("should be the right name and symbol", async function(){
     expect(await myNFT.name()).to.equal("MYNFT");
     expect(await myNFT.symbol()).to.equal("MNFT");
  })

  it("mint a NFT", async function(){
   await myNFT.connect(owner).mintNFTs(1, {
     value: ethers.utils.parseEther("0.01")
   });

   expect(await myNFT.balanceOf(owner.address)).to.equal(1);
  })

  it("Should failed if sender doesn't have enough ether to purchase NFTs", async function(){
    await expect( myNFT.connect(owner).mintNFTs(2, {
      value: ethers.utils.parseEther("0.01")
    })).to.be.revertedWith("Not enought ether to purchase NFTs");
  })

  it("reserve 10 NFTs ", async function(){
    await myNFT.connect(owner).reserveNFTs();
 
    expect(await myNFT.balanceOf(owner.address)).to.equal(10);
  })


  it("Should failed if not enough NFTs", async function(){
    await myNFT.connect(owner).reserveNFTs();
    await myNFT.connect(owner).reserveNFTs();
    await myNFT.connect(owner).reserveNFTs();
    await myNFT.connect(owner).reserveNFTs();
    await myNFT.connect(owner).reserveNFTs();
    await myNFT.connect(owner).reserveNFTs();
    await myNFT.connect(owner).reserveNFTs();
    await myNFT.connect(owner).reserveNFTs();
    await myNFT.connect(owner).reserveNFTs();
    await expect(myNFT.connect(owner).reserveNFTs()).to.be.revertedWith("Not enough NFTs");
  })
});
