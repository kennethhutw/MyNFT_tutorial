import { useEffect, useState } from 'react';
import './App.css';
import contract from './contracts/MyNFT.json';

import {ethers} from 'ethers';

const contractAddress = "0xa06e693d7663d75f4ef3fa6132bee72137710ce7";
const abi = contract.abi;

function App() {

  const [currentAccount, setCurrentAccount]= useState(null);

  const checkWalletIsConnected =async () => { 
    const {ethereum} = window;

    if(!ethereum){
      alert("Make sure you have metamask installed");
      return;
    }

    try{
      const accounts = await ethereum.request({method:"eth_accounts"});
      console.log("Found accounts ! Address", accounts);
      if(accounts.length !==0){
        const account = accounts[0];
        setCurrentAccount(account);
      }else{
        console.log("Found authorized accounts !", accounts);
      }
     
    }catch(err){
      console.error("Error connect", err);
    }
  }


  const connectWalletHandler = async () => { 
    const {ethereum} = window;

    if(!ethereum){
      alert("Please install metamask");
    }

    try{
      const accounts = await ethereum.request({method:"eth_requestAccounts"});
      console.log("Found accounts ! Address", accounts);
      if(accounts.length !==0){
        const account = accounts[0];
        setCurrentAccount(account);
      }else{
        console.log("Found authorized accounts !", accounts);
      }
     
    }catch(err){
      console.error("Error connect", err);
    }

  }

  const mintNftHandler = async () => {
    try {
      const {ethereum} = window;

      if(ethereum){
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const nftContract = new ethers.Contract(contractAddress, abi, signer);

        console.log("initialize payment");

        let nftTxn= await nftContract.mintNFTs(1, {value:ethers.utils.parseEther("0.01")});
        console.log("Mining ... please wait");

        await nftTxn.wait();

        console.log(`Mined, see transaction: https://rinkeby.etherscan.io/tx/${nftTxn.hash}`);


      } else{
        console.log("ethereum object does not exist");
      }
    }catch(error){
      console.error(error);
    }

  }

  const connectWalletButton = () => {
    return (
      <button onClick={connectWalletHandler} className='cta-button connect-wallet-button'>
        Connect Wallet
      </button>
    )
  }

  const mintNftButton = () => {
    return (
      <button onClick={mintNftHandler} className='cta-button mint-nft-button'>
        Mint NFT
      </button>
    )
  }

  useEffect(() => {
    checkWalletIsConnected();
  }, [])

  return (
    <div className='main-app'>
      <h1>MyNFT Tutorial</h1>
      <div>
        {currentAccount? mintNftButton(): connectWalletButton()}
      </div>
    </div>
  )
}

export default App;